import{j as o}from"./index-Cy5L3G6T.js";import{N as r}from"./NotService-CAvWRg-k.js";const e=()=>o.jsx(r,{});export{e as default};
