import{j as r}from"./index-Cy5L3G6T.js";const e=()=>r.jsx("div",{className:"mt-5 border-b-[1px] w-full border-[#D9D9D9]"});export{e as L};
