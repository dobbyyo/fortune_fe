const r=e=>typeof e=="string"?e.replace(/["']/g,""):JSON.parse(JSON.stringify(e).replace(/["']/g,""));export{r as c};
