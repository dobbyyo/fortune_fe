import{j as r}from"./index-Cy5L3G6T.js";import{N as t}from"./NotService-CAvWRg-k.js";const s=()=>r.jsx(t,{});export{s as default};
